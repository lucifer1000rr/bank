import retrofit2.Call;
import retrofit2.http.*;

public interface BankService {
    @FormUrlEncoded
    @POST("login.php")
    Call<LoginResponse> login(@Field("username") String user, @Field("password") String pass);

    @FormUrlEncoded
    @POST("register.php")
    Call<RegisterResponse> register(
        @Field("username") String username,
        @Field("password") String password,
        @Field("name") String name,
        @Field("account_number") String accountNumber,
        @Field("security_answer") String securityAnswer
    );
}