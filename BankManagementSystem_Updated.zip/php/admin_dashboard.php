<?php
$host = "localhost";
$db = "bank_system";
$user = "root";
$pass = "";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed");

$res_users = $conn->query("SELECT COUNT(*) as total_users FROM users");
$total_users = $res_users->fetch_assoc()['total_users'];

$res_trans = $conn->query("SELECT COUNT(*) as total_transactions FROM transactions");
$total_transactions = $res_trans->fetch_assoc()['total_transactions'];

$res_logins = $conn->query("SELECT COUNT(*) as logins_today FROM login_history WHERE DATE(login_time) = CURDATE()");
$logins_today = $res_logins->fetch_assoc()['logins_today'];

$data = [
    "total_users" => $total_users,
    "total_transactions" => $total_transactions,
    "logins_today" => $logins_today
];

echo json_encode($data);
?>