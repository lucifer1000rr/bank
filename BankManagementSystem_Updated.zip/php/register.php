<?php
$host = "localhost";
$db = "bank_system";
$user = "root";
$pass = "";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed");

$username = $_POST['username'];
$password = hash('sha256', $_POST['password']);
$name = $_POST['name'];
$account = $_POST['account_number'];
$security_answer = $_POST['security_answer'];

$stmt = $conn->prepare("INSERT INTO users (username, password, name, account_number, security_answer) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $username, $password, $name, $account, $security_answer);

echo json_encode(["status" => $stmt->execute() ? "registered" : "error"]);
?>