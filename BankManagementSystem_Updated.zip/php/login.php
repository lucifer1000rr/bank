<?php
$host = "localhost";
$db = "bank_system";
$user = "root";
$pass = "";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed");

$username = $_POST['username'];
$password = hash('sha256', $_POST['password']);

$stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND password=?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

echo json_encode(["status" => $result->num_rows > 0 ? "success" : "failed"]);
?>